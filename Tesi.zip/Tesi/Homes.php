<?php

require ("D:/Xampp/htdocs/Tesi/Index.php");

$instancia = new Header();

$header = 'Inicio';


$instancia->Headerllx($header);

print '<div class="slider">';
print '	<ul>';
print '		<li><img src="slider/slide23.png" alt=""></li>';
print '		<li><img src="slider/slide24.png" alt=""></li>';
print '		<li><img src="slider/slide25.png" alt=""></li>';
print '		<li><img src="slider/slide26.png" alt=""></li>';
print '	</ul>';
print '	<h1>BIENVENIDO A TECNOLOGICO DE ESTUDIOS SUPERIORES DE IXTAPALUCA</h1>';
print '<p>"Acerca del Tecnológico"</p>';
print '<p>El Tecnológico de Estudios Superiores de Ixtapaluca (TESI), es una Institución Pública que ofrece educación superior de excelencia, con el fin de formar profesionistas, emprendedores e investigadores competentes, con sólida preparación científica, tecnológica y humanistica, que contribuyan a elevar la calidad de vida de la sociedad.</p>';
print '</div>';

print '<div class="Contacto">';



print'<table class="texto-encima">';

print'<tr>';

print'<td>CONTACTO</td>';

print'</tr>';

print'<tr>';

print'<td>Gracias por tu interés por el tecnologico de Estudios Superiores de Ixtapaluca. Si quieres saber más, escríbeme y pronto me pondré en contacto.

Tecnológico de Estudios Superiores de Ixtapaluca
Carretera Coatepec, Callejon San Juan 7, 56580 Ixtapaluca,Mexico
</td>';

print'<td><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d120443.31955891379!2d-98.86829566680908!3d19.37548486463016!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x8a0bcd921052a741!2sTecnol%C3%B3gico%20de%20Estudios%20Superiores%20de%20Ixtapaluca!5e0!3m2!1ses!2smx!4v1669335992051!5m2!1ses!2smx" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></td>';

print'</tr>';

print'<tr>';

print'<td>TEL: ( 55 ) 13148150</td>';

print'</tr>';




print'</table>';

print '</div>';

$instancia->Footerllx($header);


?>



<style>

.slider {
	width: 100%;
	margin: auto;
	overflow: hidden;
}

.slider ul {
	display: flex;
	padding: 0;
	width: 400%;

	animation: change 20s infinite;
	animation-timing-function: ease-in;
}

.slider li {
	width: 100%;
	list-style: none;
}

.slider img {
width: 100%;
height: 520px;
}

.Contacto img {
background-size: cover;
width: 100%;
height: 550px;
}

.texto-encima{
    /* position: absolute; */
    top: 990px;
    left: 10px;
	

	font-family: Helvetica, Arial, sans-serif;

	color:aliceblue;
	font-size: 2em;
	line-height: 1.5em;

	background-image: url("slider/Contacto1.jpg");
}



@keyframes change {
	0%{margin-left: 0;}
	20%{margin-left: 0;}

	25%{margin-left: -100%;}
	45%{margin-left: -100%;}

	50%{margin-left: -200%;}
	70%{margin-left: -200%;}

	75%{margin-left: -300%;}
	100%{margin-left: -300%;}
}
  </style>