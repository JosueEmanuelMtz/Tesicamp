<?php

require ("D:/Xampp/htdocs/Tesi/Index.php");
require ("D:/Xampp/htdocs/Tesi/conect.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$systems = 'Sistemas';

$instancia = new Header();
$conect = new conect();

$header = 'Prodcutos';


$instancia->Headerllx($header);
$conect->conection();

print'<div class="contact_form">';
print'<div class="formulario">';			
print'<h1 class="header">Datos de inscripcion</h1>'; 
print'	<h3>Favor de llenar de forma correcta cada apartado</h3>';


print '<form method="POST" action="'.$_SERVER["PHP_SELF"].'">';
// print'		<form action="submeter-formulario.php" method="post">';				

						
print'					<p><label for="nombre" class="colocar_nombre">Nombre<span class="obligatorio">*</span></label><input class="innertext" type="text" name="introducir_nombre" id="nombre" required="obligatorio" placeholder="Escribe tu nombre"></p>';
							
print'					<p><label for="email" class="colocar_email">Email<span class="obligatorio">*</span></label><input class="innertext" type="email" name="introducir_email" id="email" required="obligatorio" placeholder="Escribe tu Email"></p>';
						
print'					<p><label for="telefone" class="colocar_telefono">Matricula</label><input  class="innertext" type="tel" name="introducir_telefono" id="telefono" placeholder="Matricula"></p>';		
							
// print'					<p><label for="number" class="colocar_website">Matricula</label><input class="innertext" type="number" name="introducir_website" id="number" placeholder="Escribe tu Matricula"></p>';		
							
print'					<p><label for="asunto" class="colocar_asunto">Linea de captura<span class="obligatorio">*</span></label><input class="innertext" type="text" name="introducir_asunto" id="assunto" required="obligatorio" placeholder="Escribe Linea de captura"></p>';		

print'	<p><label for="asunto" class="colocar_asunto">Selecciona tu carrera</label></p>';		

print'  <select class="select" name="select">';
print'  <option value="llx_system">Ingeniería en Sistemas Computacionales</option>';
print'  <option value="llx_ambi" selected>Ingeniería Ambiental</option>';
print'  <option value="llx_electr">Ingeniería Electrónica</option>';
print'  <option value="llx_bio">Ingeniería Biomédica</option>';
print'  <option value="llx_info">Ingeniería Informática</option>';
print'  <option value="llx_admi">Licenciatura en Administración</option>';
print'  <option value="llx_arqui">Arquitectura</option>';
print'</select>';

print '<br>';

print'	<p><label for="asunto" class="colocar_asunto">Favor de adjuntar un archivo pdf con tu kardex, tira de materias, linea de captura para pago en ventanilla, Comprobante o recibo de pago
 Nota: el nombre de tu archivo tine que ser el numero de matricula</label></p>';		


print'<input id="fileTest" name="fileTest" type="file">';

print'					<button type="submit" name="validar" value="Validar" id="enviar"><p>Enviar</p></button>';
print "<div class='tabsAction'>";
// print '<input class="butAction reposition" type="submit" name="validar" value="Validar">';
print'</div>';

print'					<p class="aviso"><span class="obligatorio"> * </span>los campos son obligatorios.</p>';
						
print'		</form>';
print'		</div>';
print'	</div>';

$instancia->Footerllx($header);

if(isset($_POST['validar'])){

  $mysqli = new mysqli("localhost:3307", "root", "", "hacktesi");
  if ($mysqli->connect_errno) {
      echo "Falló la conexión a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
  }
  

  if($_POST["select"]=="llx_system"){

   
    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql);                

  }
  if($_POST["select"]=="llx_ambi"){

    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql); 

  }
  if($_POST["select"]=="llx_electr"){

    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql); 

  }
  if($_POST["select"]=="llx_bio"){

    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql); 

  }
  if($_POST["select"]=="llx_info"){

    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql); 

  }
  if($_POST["select"]=="llx_admi"){

    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql); 

  }
  if($_POST["select"]=="llx_arqui"){

    $sql="INSERT INTO ".$_POST["select"]." (Nombre, Email, Matricula, Linea_de_captura)";
    $sql.= "VALUES ('".$_POST["introducir_nombre"]."', '".$_POST["introducir_email"]."',".$_POST["introducir_telefono"]." , ".$_POST["introducir_asunto"].")";     
    $ressql = $mysqli->query($sql);  

  }


  // "D:\xampp\htdocs\Tesi\enviar\vendor\autoload.php"

require 'enviar/vendor/autoload.php';
 
$mail = new PHPMailer(true);

try {
    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'josue.emanuelmtz@gmail.com';
    $mail->Password = 'vzrougvjujhmohjg';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;
    
    

    $mail->setFrom('josue.emanuelmtz@gmail.com', 'Emanuel Martinez');
    $mail->addAddress($_POST["introducir_email"], 'Josue Aburto');
    // $mail->addCC('concopia@gmail.com');
    

    // $mail->addAttachment('docs/dashboard.png', 'Dashboard.png');
    

    $mail->isHTML(true);
    $mail->Subject = 'INCRIPCIONES TESI';
    $mail->Body = 'Hola, <br/>TUS DATOS FUERON ENVIADOS DE FORMA CORRECTA POR FAVOR ESPERA LA RESPUESTA DE INSCRIPCION<b>Gmail</b>.';
    $mail->send();
    

    
} catch (Exception $e) {
    // echo 'Mensaje ' . $mail->ErrorInfo;
}


}


?>

<style>

.contact_form{	
	width: 460px; 
  height: auto;
  margin: 80px auto;
	border-radius: 10px;  
	padding-top: 30px;
	padding-bottom: 20px;  
  background-color: #fbfbfb; 
  padding-left: 30px; 
}


input.innertext{
	background-color: #fbfbfb; 
	width: 408px; 
	height: 40px; 
	border-radius: 5px;  
	border-style: solid; 
	border-width: 1px; 
	border-color: #1fcd0a; 
	margin-top: 10px;  
	padding-left: 10px;
  margin-bottom: 20px; 
}


textarea{
  background-color: #fbfbfb; 
	width: 405px; 
	height: 150px; 
	border-radius: 5px;  
	border-style: solid; 
	border-width: 1px; 
	border-color: #ab4493; 
	margin-top: 10px;  
	padding-left: 10px;
  margin-bottom: 20px; 
  padding-top: 15px; 
}


label{
  display: block; 
	float: center; 	
}


button{
	height: 45px; 
	padding-left: 5px;
	padding-right: 5px; 	
	margin-bottom: 20px; 
	margin-top: 10px; 	
	text-transform: uppercase;
	background-image: radial-gradient(circle at 49.45% 53.13%, #6fd100 0, #51cf00 25%, #1fcd0a 50%, #00ca1d 75%, #00c82c 100%);
	border-color:#1fcd0a;
	border-style: solid; 
	border-radius: 10px;	
	width: 420px;   
  cursor: pointer;
}


button p{
	color: #fff; 
}

.aviso{
	font-size: 13px;  
	color: #0e0e0e;  
}


h1.header{
	font-size: 39px;  
	text-align: letf; 
	padding-bottom: 20px; 
	color:#00ca1d;
}


h3{
	font-size: 16px; 
	padding-bottom: 30px;
	color: #0e0e0e;   
}


p{
	font-size: 14px; 
	color: #0e0e0e; 
}


::-webkit-input-placeholder {
 color: #a8a8a8;
}


::-webkit-textarea-placeholder {
 color: #a8a8a8;
}


.formulario input:focus{
	outline:0;
	border: 1px solid red;
}

.select {
  border: 1px solid #ccc;
  width: 140px;
  overflow: hidden;
  background: #fff url("flecha-abajo.gif") no-repeat 90% center;
}

.select select {
    padding: 5px 8px;
    width: 130%;
    border: none;
    box-shadow: none;
    background-color: transparent;
    background-image: none;
    appearance: none;
}

</style>

