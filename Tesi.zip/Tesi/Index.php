<?php

class Header {

	function Headerllx($header=0)
    {

		if(!empty($header))
		{
		print'<title>TESI</title>';

		print'<link rel="stylesheet" href="style.css">';
		
		print'<body>';
		
		print'<header id="main-header">';
		
		print'<a id="logo-header" href="#">';
		print'<img style="width: 59px" src="logos\tesi.jpg"/>';	
		print'</a>';
		
		print'<a id="logo-header" href="'.$_SERVER['PHP_SELF'].'">';
		print'<span class="first-name">TECNOLOGICO DE ESTUDIOS SUPERIORES</span>';	
		print'<span class="site-name">DE IXTAPALUCA</span>';	
		print'</a>';
		
		print'<nav>';
		print'<ul>';
		print'<li><a href="/Tesi/Admin.php">Admin</a></li>';
		print'<li><a href="/Tesi/Homes.php">Inicio</a></li>';
		print'<li><a href="/Tesi/Product.php">Recepcion de datos</a></li>';
		// print'<li><a href="/CircuitosDeOriente/Shoping.php">Compras</a></li>';
		print'<li><a href="/CircuitosDeOriente/Login.php">Login</a></li>';
		print'</ul>';
		print'</nav>';//nav
		
		print'</header>'; // main-header
		
		print'<section id="main-content">';
		print '<article>';	
		print '<div class="content">';
		
	}

	}

	function Footerllx($header=0){

		if(!empty($header))
		{
			print'</div>';
			print'</article>';
			print'</section>';
			
			print'<footer id="main-footer">';
			print'<p>&copy; 2022 <a href="https://tesi.org.mx/">Tecnológico de Estudios Superiores de Ixtapaluca.com</a></p>';
			print'</footer>';
			print'</body>';
			
		}
		
	}
    



}


?>


<!-- <!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"> -->


<style>

body {
	margin: 0;
	padding: 0;	
	font-family: Helvetica, Arial, sans-serif;

	color: #1d1d1f;
	background: #f2f2f2; 
	font-size: 1em;
	line-height: 1.5em;
}

h1 {
	font-size: 4.3em;
	line-height: 1.3em;
	margin: 15px 0;
	text-align: center;
	font-weight: 300;
		/* p {
  font: oblique bold 120% cursive;
} */
}

p {
	margin: 0 0 1.5em 0;
}

img {
	max-width: 100%;
	height: auto;
}
/* Estas líneas de CSS las usaremos para dar estilo a la cabecera: */

#main-header {
	background: #333;
	color: white;
	height: 80px;
}	
	#main-header a {
		color: white;
	}

/*
 * Logo
 */
#logo-header {
	float: left;
	padding: 15px 0 0 20px;
	text-decoration: none;
}
	#logo-header:hover {
		color: #0b76a6;
	}
	#logo-header .first-name {
		display: block;
		font-weight: 700;
		font-size: 0.8em;
		/* color:red; */
	}
	
	
	#logo-header .site-name {
		display: block;
		font-weight: 700;
		font-size: 2.8em;
		/* color: blue; */
	}
	
	#logo-header .site-desc {
		display: block;
		font-weight: 300;
		font-size: 0.8em;
		color: #999;
	}
/* 
 * Navegación
 */
nav {
	float: right;
}
	nav ul {
		margin: 0;
		padding: 0;
		list-style: none;
		padding-right: 20px;
	}
	
		nav ul li {
			display: inline-block;
			line-height: 80px;
		}
			
			nav ul li a {
				display: block;
				padding: 0 10px;
				text-decoration: none;
			}
			
				nav ul li a:hover {
					background: #0b76a6;
				}
/* Con estos estilos aplicaremos diseño al contenido: */

#main-content {
	background:#f2f2f2;  
	width: 100%;
	max-width: 1500px;
	margin: 0px 0px;
	box-shadow: 0 0 10px rgba(0,0,0,.1);
}

	#main-content header,
	#main-content .content {
		padding: 0px;
	}
/* Y por último, con esto estilizaremos el pie de página: */

#main-footer {	
	background-image: radial-gradient(circle at 50% -20.71%, #bde865 0, #a6e160 16.67%, #8bd859 33.33%, #6acc50 50%, #42c049 66.67%, #00b646 83.33%, #00ae48 100%);
	color: white;
	text-align: center;
	padding: 20px;
	margin-top: 0px;
}
	#main-footer p {
		margin: 0;
	}
	
	#main-footer a {
		color: white;
	}

    #main-header {
	background-image: radial-gradient(circle at 50% -20.71%, #bde865 0, #a6e160 16.67%, #8bd859 33.33%, #6acc50 50%, #42c049 66.67%, #00b646 83.33%, #00ae48 100%);
	color: white;
	height: 80px;
	
	width: 100%; /* hacemos que la cabecera ocupe el ancho completo de la página */
	left: 0; /* Posicionamos la cabecera al lado izquierdo */
	top: 0; /* Posicionamos la cabecera pegada arriba */
	position:fixed; /* Hacemos que la cabecera tenga una posición fija */
}


</style>


	<script type="text/javascript">
		window.addEventListener("#main-header",function(){
			var header = document.querySelector("#main-header")
			header.classList.toggle("abajo",window.scrrollY>0);
		})

	</script>

</html>