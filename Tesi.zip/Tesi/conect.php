<?php

class conect {

    function conection()
    {


$servername = "localhost:3307"; // Nombre/IP del servidor
$database = "hacktesi"; // Nombre de la BBDD
$username = "root"; // Nombre del usuario
$password = ""; // Contraseña del usuario
// Creamos la conexión
$con = mysqli_connect($servername, $username, $password, $database);
// Comprobamos la conexión
if (!$con) {
    die("La conexión ha fallado: " . mysqli_connect_error());
}
// echo "Conexión satisfactoria";
mysqli_close($con);

}

}
?>